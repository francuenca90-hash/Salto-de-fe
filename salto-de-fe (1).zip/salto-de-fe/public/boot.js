// Registra el service worker (modo offline). En la app nativa (Capacitor) no hace falta:
// los archivos ya van dentro del APK.
(function () {
  var nativa = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  if ('serviceWorker' in navigator && !nativa) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () { /* sin offline, pero el juego sigue funcionando */ });
    });
  }
})();
