module Content

open Types

/// Todos los nodos del juego, unidos. Al añadir un acto, súmalo aquí.
let nodos : Map<string, Nodo> =
    [ Prologo.nodos; Acto1.nodos; Acto2.nodos; Acto3.nodos ]
    |> List.fold (fun acc m -> Map.fold (fun a k v -> Map.add k v a) acc m) Map.empty

let private destinos (o: Opcion) =
    match o.Prueba with
    | None -> [ o.Siguiente ]
    | Some p -> [ p.SiguienteExito; p.SiguienteFallo ]

/// Devuelve los problemas de integridad del guion (saltos a nodos que no existen).
let validar () : string list =
    [ for KeyValue(id, n) in nodos do
          let todas =
              match n.Limite with
              | Some l -> l.Defecto :: n.Opciones
              | None -> n.Opciones
          for o in todas do
              for d in destinos o do
                  if not (Map.containsKey d nodos) then
                      yield sprintf "Nodo '%s': la opción «%s» apunta a '%s', que no existe" id o.Texto d ]
