module Acto2

open Types
open Dsl

// Resumen del acto:
//  A. Llegada y fase humanitaria (escolta, reparto, Samir)
//  B. Primera emboscada (con límite de tiempo) y su secuela
//  C. Reconstrucción de la escuela
//  D. Noticia: Lucía rompe la relación (tono según la despedida del Acto I)
//  E. Segundo ataque (fuego indirecto) y punto de giro: Samir
//  F. Cierre y enlace con el Acto III

let nodos : Map<string, Nodo> =
    aMapa
        [ // ---------- A. Llegada y fase humanitaria ----------
          nodo "acto2_inicio" "Narrador"
              "Base de apoyo avanzado, provincia de Badghis. Calor seco, polvo en los dientes y el rumor constante de los generadores. A lo lejos, montañas sin nombre en tu mapa."
              [ op "Colgar la funda de la guitarra junto a tu litera." Neutro Siempre [ Estres -2 ] "acto2_briefing"
                op "Dejar la funda al fondo de la taquilla." Seco Siempre [ Estres 2 ] "acto2_briefing" ]

          nodo "acto2_briefing" "Teniente Vidal"
              "«Escoltamos el convoy de ayuda hasta Deh Sabz: víveres, material y la reconstrucción de la escuela. Es una misión humanitaria, pero nadie nos garantiza que nos reciban con flores. Ojos abiertos.»"
              [ op "Entendido, mi teniente." Disciplinado Siempre [ Mandos 3; Disciplina 1 ] "acto2_escolta"
                op "¿Y si nos atacan?" Neutro Siempre [ Estres 2 ] "acto2_escolta"
                op "¿Para qué sirve repartir sacos de harina?" Seco Siempre [ Mandos -2; Estres 2 ] "acto2_escolta" ]

          nodo "acto2_escolta" "Narrador"
              "El convoy avanza despacio por una pista de tierra. Cuatro horas de silencio y calor. A la izquierda, un barranco; a la derecha, muros de adobe vacíos."
              [ prueba "Mantener la atención en el flanco asignado." Disciplinado Siempre [] ADisciplina 45 10
                    ([ Mandos 2 ], "acto2_aldea")
                    ([ Estres 6 ], "acto2_aldea")
                op "Charlar con Farid, el intérprete." Empatico Siempre [ Humanidad 2; Estres -3; PonerBandera "habla_farid" ] "acto2_aldea"
                op "Dejar que la mente se vaya a casa." Seco Siempre [ Estres 3; Resistencia 5 ] "acto2_aldea" ]

          nodo "acto2_aldea" "Farid"
              "Deh Sabz. Mujeres, ancianos y niños se asoman sin acercarse. Farid, el intérprete, te susurra: «Hasta que vean que no venís a llevaros nada, no se acercarán.»"
              [ op "Empezar a repartir el material sin esperar." Disciplinado Siempre [ Disciplina 1; Mandos 2; Resistencia -10 ] "acto2_reparto"
                op "Sentarte con el anciano y escuchar lo que necesita." Empatico Siempre [ Humanidad 4; Estres -3; PonerBandera "escucho_al_anciano" ] "acto2_reparto"
                op "Mantener distancia y vigilar el perímetro." Seco Siempre [ Estres 2; Mandos 1; PonerBandera "distante" ] "acto2_reparto" ]

          nodo "acto2_reparto" "Narrador"
              "Hay que descargar los camiones antes de que caiga el sol. Los sacos pesan más de lo que parece."
              [ prueba "Cargar con los sacos más pesados." Neutro Siempre [] AFisico 50 20
                    ([ Companeros 3; Humanidad 1 ], "acto2_samir")
                    ([ Resistencia -5; Estres 3 ], "acto2_samir")
                op "Organizar la fila para que el reparto sea justo." Disciplinado Siempre [ Humanidad 2; Mandos 2; Resistencia -10 ] "acto2_samir" ]

          nodo "acto2_samir" "Narrador"
              "Un niño de unos ocho años, descalzo, os observa desde un muro bajo. Farid dice que se llama Samir y que su padre murió hace dos años. No se mueve: solo mira tu mochila, de la que asoma la funda de la guitarra."
              [ op "Sacar la guitarra y rasgar un par de acordes." Empatico Siempre [ Humanidad 3; Estres -4; PonerBandera "samir_conoce_guitarra" ] "acto2_emboscada1"
                op "Hacerle un gesto con la mano." Neutro Siempre [ Humanidad 1 ] "acto2_emboscada1"
                op "Ignorarle: no estás aquí para hacer amigos." Seco Siempre [ Estres 2 ] "acto2_emboscada1" ]

          // ---------- B. Primera emboscada (con tiempo) ----------
          nodoT "acto2_emboscada1" "Voz por radio" "Un chasquido seco. Luego otro. Polvo saltando en la pista, junto al primer vehículo. Los atacantes, insurgentes talibanes, no se dejan ver. «¡Contacto! ¡Cobertura!»" 8
              (op "Te quedas inmóvil un instante, sin reaccionar." Seco Siempre [ Estres 12; Companeros -2 ] "acto2_emb1_despues")
              [ prueba "Aplicar el procedimiento: cobertura y repliegue ordenado." Disciplinado Siempre [] ADisciplina 50 20
                    ([ Mandos 3; Disciplina 1 ], "acto2_emb1_despues")
                    ([ Estres 8 ], "acto2_emb1_despues")
                prueba "Ayudar a Marcos a ponerse a cubierto." Empatico Siempre [ Humanidad 2 ] AFisico 50 25
                    ([ Companeros 4 ], "acto2_emb1_despues")
                    ([ Estres 6; Resistencia -10 ], "acto2_emb1_despues")
                op "Parapetarte tras el vehículo y esperar." Neutro Siempre [ Estres 5; Resistencia -5 ] "acto2_emb1_despues" ]

          nodo "acto2_emb1_despues" "Teniente Vidal"
              "Nadie herido de gravedad. Los atacantes se retiran tan rápido como llegaron. Vidal cuenta cabezas con la mandíbula tensa. «Esto es lo que hay. Seguimos con la misión.»"
              [ op "Sí, mi teniente." Disciplinado Siempre [ Mandos 2; Estres -2 ] "acto2_noche_base"
                op "¿Y si hay otra emboscada?" Neutro Siempre [ Estres 2 ] "acto2_noche_base"
                op "Esto no hacía falta." Seco Siempre [ Mandos -2; Estres 3 ] "acto2_noche_base" ]

          nodo "acto2_noche_base" "Marcos"
              "Noche en la base. Marcos se sienta a tu lado, con las manos todavía temblorosas. «Hoy he pasado un miedo de muerte. ¿Y tú?»"
              [ op "Yo también." Empatico Siempre [ Estres -5; Companeros 5; Humanidad 2 ] "acto2_noche_guitarra"
                op "Estoy bien." Seco Siempre [ Estres 4; Companeros -1; PonerBandera "disimula" ] "acto2_noche_guitarra"
                op "Hay que seguir." Disciplinado Siempre [ Mandos 1; Disciplina 1; Estres -1 ] "acto2_noche_guitarra" ]

          nodo "acto2_noche_guitarra" "Narrador"
              "La funda de la guitarra sigue donde la dejaste. Fuera, los generadores no se detienen."
              [ op "Tocar un rato en voz baja." Neutro Siempre [ Estres -8; Humanidad 1; Resistencia 25 ] "acto2_escuela"
                op "Dormir sin más." Neutro Siempre [ Resistencia 20 ] "acto2_escuela" ]

          // ---------- C. Reconstrucción de la escuela ----------
          nodo "acto2_escuela" "Narrador"
              "Dos semanas después. La escuela de Deh Sabz toma forma: paredes nuevas, techo a medio levantar. Los aldeanos trabajan a vuestro lado. Samir te sigue a todas partes sin decir palabra."
              [ prueba "Subir al andamio a colocar las vigas." Neutro Siempre [] AFisico 52 25
                    ([ Humanidad 2; Companeros 3 ], "acto2_correo")
                    ([ Resistencia -5; Estres 4 ], "acto2_correo")
                op "Improvisar una clase de dibujo con los niños." Empatico Siempre [ Humanidad 3; Estres -4 ] "acto2_correo"
                op "Coordinar el reparto de materiales." Disciplinado Siempre [ Mandos 3; Disciplina 1; Resistencia -10 ] "acto2_correo" ]

          // ---------- D. La ruptura ----------
          nodo "acto2_correo" "Narrador"
              "Al volver a la base te espera un mensaje de Lucía. Lo has estado esperando y temiendo a partes iguales."
              [ op "Leer el mensaje." Neutro (Bandera "despedida_fria") [] "acto2_noticia_fria"
                op "Leer el mensaje." Neutro (Bandera "despedida_confusa") [] "acto2_noticia_confusa"
                op "Leer el mensaje." Neutro (Bandera "despedida_sincera") [] "acto2_noticia_sincera" ]

          nodo "acto2_noticia_fria" "Lucía"
              "«Ya sabía que lo harías. Te escribo para no repetirlo por teléfono: se acabó, Dani. Tus cosas están en cajas en el portal. No me llames.»"
              [ op "Releerlo." Neutro Siempre [ Pareja -50; Estres 25; PonerBandera "relacion_terminada" ] "acto2_ruptura" ]

          nodo "acto2_noticia_confusa" "Lucía"
              "«No sé cómo decirte esto sin hacerte daño, y supongo que eso ya lo resume todo. Necesito parar. Cuando vuelvas, ya no estaré.»"
              [ op "Releerlo." Neutro Siempre [ Pareja -50; Estres 25; PonerBandera "relacion_terminada" ] "acto2_ruptura" ]

          nodo "acto2_noticia_sincera" "Lucía"
              "«Te dije que entendía tu miedo y sigo entendiéndolo. Pero yo no puedo vivir esperando una llamada. Cuídate mucho. Y toca esa guitarra, por favor.»"
              [ op "Releerlo." Neutro Siempre [ Pareja -50; Estres 25; PonerBandera "relacion_terminada" ] "acto2_ruptura" ]

          nodo "acto2_ruptura" "Narrador"
              "Releer las líneas no las cambia. Fuera, alguien grita una orden; dentro, el mundo se te ha quedado muy pequeño."
              [ op "Salir a tocar la guitarra al borde de la base." Neutro Siempre [ Estres -10; Humanidad 2; PonerBandera "toco_tras_ruptura" ] "acto2_patrulla"
                op "Buscar a Marcos y hablar." Empatico Siempre [ Companeros 5; Humanidad 3; Estres -6 ] "acto2_patrulla"
                op "Aislarte y no hablar con nadie." Seco Siempre [ Estres 8; Companeros -3; PonerBandera "se_aisla" ] "acto2_patrulla"
                op "Escribir una respuesta furiosa y enviarla." Impulsivo Siempre [ Estres 5; Mandos -2 ] "acto2_patrulla" ]

          // ---------- E. Segundo ataque y punto de giro ----------
          nodo "acto2_patrulla" "Teniente Vidal"
              "«Nuevo convoy a Deh Sabz con el material de la escuela. Necesito a todos al cien por cien, Ibáñez. ¿Estás en condiciones?»"
              [ op "Sí, mi teniente." Disciplinado Siempre [ Mandos 2 ] "acto2_plaza"
                op "No me apetece hablar de ello." Seco Siempre [ Estres 2 ] "acto2_plaza"
                op "Si soy sincero, no mucho. Pero iré." Empatico (HumanidadMin 25) [ Mandos 3; Humanidad 2 ] "acto2_plaza" ]

          nodo "acto2_plaza" "Narrador"
              "Mediodía en la plaza de Deh Sabz. Los niños corren hacia los camiones. Samir llega el primero, con la gorra que le regalaron en la escuela."
              [ op "Sonreír y entregarle los cuadernos." Neutro Siempre [ Humanidad 2; Estres -2 ] "acto2_emboscada2"
                op "Mantener posición de vigilancia." Disciplinado Siempre [ Mandos 1 ] "acto2_emboscada2" ]

          nodoT "acto2_emboscada2" "Narrador" "Un silbido agudo y un estruendo sordo. Polvo, gritos, gente corriendo. Fuego indirecto sobre la plaza. Samir se ha quedado en mitad del espacio abierto, paralizado, a quince metros de ti." 6
              (op "Echas a correr hacia él sin pensar." Neutro Siempre [ Humanidad 10; Estres 8; Resistencia -25; PonerBandera "salvo_a_samir"; PonerBandera "giro_instintivo" ] "acto2_rescate")
              [ op "Correr hacia Samir." Neutro Siempre [ Humanidad 10; Estres 8; Resistencia -25; PonerBandera "salvo_a_samir"; PonerBandera "giro_instintivo" ] "acto2_rescate"
                prueba "Pedir cobertura y avanzar por el lateral." Disciplinado Siempre [ Humanidad 10; PonerBandera "salvo_a_samir" ] ADisciplina 50 15
                    ([ Estres 4; Mandos 3 ], "acto2_rescate")
                    ([ Estres 10; Resistencia -10 ], "acto2_rescate") ]

          nodo "acto2_rescate" "Narrador"
              "Lo agarras por el chaleco, lo arrastras tras el muro bajo y le cubres el cuerpo con el tuyo. Notas su latido contra el pecho antes que el tuyo. Cuando cesa el estruendo, Samir te mira sin llorar. Está vivo."
              [ op "Comprobar que no está herido." Neutro Siempre [ Humanidad 2; Estres -2 ] "acto2_cobijo"
                op "Abrazarle sin decir nada." Empatico Siempre [ Humanidad 4; Estres -6 ] "acto2_cobijo"
                op "Entregarlo a Vidal y recomponerte." Disciplinado Siempre [ Mandos 2; Disciplina 1 ] "acto2_cobijo" ]

          nodo "acto2_cobijo" "Farid"
              "La madre de Samir llega corriendo. Farid traduce con la voz rota: «Dice que Dios te ha puesto en su camino.»"
              [ op "Cualquiera lo habría hecho." Seco Siempre [ Estres 1; Humanidad 1 ] "acto2_giro"
                op "Sentarte junto a Samir, en silencio." Neutro Siempre [ Humanidad 4; Estres -5 ] "acto2_giro"
                op "Decirle que no podía dejarlo ahí." Empatico Siempre [ Humanidad 5; Estres -6 ] "acto2_giro" ]

          nodo "acto2_giro" "Narrador"
              "Esa noche, en la base, la guitarra suena distinta. Durante meses cada decisión fue un cálculo: qué cuesta, qué rinde, qué te protege. Hoy no calculaste nada. Y por primera vez en mucho tiempo, no te molesta oírte."
              [ op "Tocar para quien quiera escuchar." Neutro Siempre [ Humanidad 5; Estres -10; Companeros 4; PonerBandera "cambio_perspectiva"; PonerBandera "toca_para_todos" ] "acto2_cierre"
                op "Quedarte a solas con la guitarra." Neutro Siempre [ Humanidad 3; Estres -8; PonerBandera "cambio_perspectiva" ] "acto2_cierre" ]

          // ---------- F. Cierre y enlace con el Acto III ----------
          nodo "acto2_cierre" "Teniente Vidal"
              "«Ibáñez, tengo noticias. Una patrulla mixta, compañeros y varios civiles, ha perdido contacto en la sierra. Salimos de madrugada. Necesito saltadores con tu cualificación.»"
              [ op "Cuente conmigo, mi teniente." Disciplinado Siempre [ Mandos 3 ] "acto2_fin"
                op "Voy. Aunque no sé si estoy listo." Empatico Siempre [ Humanidad 2; Mandos 2 ] "acto2_fin"
                op "Daré lo que haga falta." Neutro Siempre [ Resistencia 10 ] "acto2_fin" ]

          nodo "acto2_fin" "Narrador"
              "Amanece sobre Badghis. El helicóptero espera con las palas ya girando y el polvo levantado te llena la boca de sabor a tierra."
              [ op "Subir." Neutro Siempre [] "acto3_amanecer" ] ]
