/// Helpers para escribir contenido de forma compacta.
module Dsl

open Types

let op texto tono cond efectos sig : Opcion =
    { Texto = texto
      Tono = tono
      Condicion = cond
      Efectos = efectos
      Siguiente = sig
      Prueba = None }

/// Opción con prueba: (efectos, siguiente) si se supera y (efectos, siguiente) si no.
let prueba texto tono cond efectos atributo dificultad coste (efOk, sigOk) (efKo, sigKo) : Opcion =
    { Texto = texto
      Tono = tono
      Condicion = cond
      Efectos = efectos
      Siguiente = sigOk
      Prueba =
        Some
            { Atributo = atributo
              Dificultad = dificultad
              CosteResistencia = coste
              SiExito = efOk
              SiguienteExito = sigOk
              SiFallo = efKo
              SiguienteFallo = sigKo } }

let nodo id personaje texto opciones : Nodo =
    { Id = id
      Personaje = personaje
      Texto = texto
      Dinamico = None
      Opciones = opciones
      Limite = None }

/// Nodo con límite de tiempo: al agotarse los segundos se aplica la opción `defecto`.
let nodoT id personaje texto segundos defecto opciones : Nodo =
    { Id = id
      Personaje = personaje
      Texto = texto
      Dinamico = None
      Opciones = opciones
      Limite = Some { Segundos = segundos; Defecto = defecto } }

/// Nodo cuyo texto se calcula a partir del estado de la partida.
let nodoD id personaje (texto: Estado -> string) opciones : Nodo =
    { Id = id
      Personaje = personaje
      Texto = ""
      Dinamico = Some texto
      Opciones = opciones
      Limite = None }

let aMapa (nodos: Nodo list) : Map<string, Nodo> =
    nodos |> List.map (fun n -> n.Id, n) |> Map.ofList
