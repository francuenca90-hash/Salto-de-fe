module Acto1

open Types
open Dsl

let nodos : Map<string, Nodo> =
    aMapa
        [ // --- Reparto inicial de puntos ---
          nodo "acto1_inicio" "Sargento Rubio"
              "Centro de instrucción. «Tenéis tres semanas. No podéis ser buenos en todo: elegid en qué os vais a dejar la piel.»"
              [ op "Entrenar la forma física." Neutro Siempre [ Fisico 8; Resistencia 5 ] "acto1_marcha"
                op "Cuidar la disciplina y el procedimiento." Disciplinado Siempre [ Disciplina 8; Mandos 2 ] "acto1_marcha"
                op "Repetir la técnica de salto." Neutro Siempre [ Paracaidista 8 ] "acto1_marcha" ]

          // --- Marcha con mochila ---
          nodo "acto1_marcha" "Narrador"
              "Marcha de veinte kilómetros con equipo completo. A mitad de camino, Marcos empieza a quedarse atrás con la mochila al límite."
              [ prueba "Mantener el ritmo del grupo." Disciplinado Siempre [] AFisico 55 25
                    ([ Companeros 2 ], "acto1_marcha_ok")
                    ([ Estres 8; Mandos -2 ], "acto1_marcha_ko")
                op "Ayudar a Marcos con la mochila." Empatico Siempre [ Resistencia -35; Companeros 6; Humanidad 3 ] "acto1_marcha_ayuda" ]

          nodo "acto1_marcha_ok" "Narrador"
              "Llegas entero. El sargento apunta algo en su cuaderno sin mirarte."
              [ op "Continuar." Neutro Siempre [] "acto1_noche" ]

          nodo "acto1_marcha_ko" "Narrador"
              "Te quedas atrás en el último tramo. Llegas arrastrando los pies y oyes risas al fondo de la fila."
              [ op "Continuar." Neutro Siempre [] "acto1_noche" ]

          nodo "acto1_marcha_ayuda" "Marcos"
              "«Te debo una, ermitaño.» Llegáis los últimos, pero juntos."
              [ op "Continuar." Neutro Siempre [] "acto1_noche" ]

          // --- Noche en el barracón: la guitarra ---
          nodo "acto1_noche" "Marcos"
              "Barracón, después de cenar. Marcos señala la funda que asoma bajo tu litera. «Dicen que tocas. Venga, una.»"
              [ op "Tocar unos acordes." Empatico Siempre [ Companeros 4; Estres -8; Humanidad 2; Resistencia 30; PonerBandera "toco_barracon" ] "acto1_salto"
                op "No toco para nadie." Seco Siempre [ Companeros -2; Resistencia 30 ] "acto1_salto" ]

          // --- Salto con viento adverso ---
          nodo "acto1_salto" "Jefe de salto"
              "Puerta del avión abierta. El viento en zona de lanzamiento es más fuerte de lo previsto. «Cinco segundos, Ibáñez. Decide.»"
              [ prueba "Saltar siguiendo el procedimiento." Neutro Siempre [] AParacaidista 48 15
                    ([ Mandos 3 ], "acto1_salto_ok")
                    ([ Estres 10 ], "acto1_salto_ko")
                op "Pedir que se aplace el salto." Disciplinado (DisciplinaMin 55) [ Mandos 2; Estres -3 ] "acto1_lesion" ]

          nodo "acto1_salto_ok" "Narrador"
              "Apertura limpia y aterrizaje seco. Por primera vez en semanas sonríes sin darte cuenta."
              [ op "Continuar." Neutro Siempre [] "acto1_lesion" ]

          nodo "acto1_salto_ko" "Narrador"
              "El viento te arrastra veinte metros. Aterrizas mal, con el hombro dolorido y el orgullo peor."
              [ op "Continuar." Neutro Siempre [] "acto1_lesion" ]

          // --- Compañero lesionado ---
          nodo "acto1_lesion" "Narrador"
              "En el circuito de obstáculos, Marcos se tuerce el tobillo y cae. El resto del pelotón ya ha pasado de largo."
              [ op "Pararte y ayudarle a salir." Empatico Siempre [ Humanidad 3; Companeros 5; Resistencia -10 ] "acto1_bronca"
                op "Seguir. El cronómetro corre." Seco Siempre [ Companeros -4; PonerBandera "dejo_a_marcos" ] "acto1_bronca"
                op "Avisar a un mando y continuar." Disciplinado Siempre [ Mandos 3 ] "acto1_bronca" ]

          // --- Bronca de un mando ---
          nodo "acto1_bronca" "Teniente Vidal"
              "El teniente te espera en el barracón. «Dicen que eres el mejor saltador de la compañía y el peor compañero. ¿Cuál de las dos cosas te enorgullece?»"
              [ op "A sus órdenes, mi teniente. Corregiré." Disciplinado Siempre [ Mandos 4; Disciplina 2 ] "acto1_convocatoria"
                op "Prefiero que me juzguen por los saltos." Seco Siempre [ Mandos -3; Estres 4 ] "acto1_convocatoria"
                op "Tiene razón. No lo estoy haciendo bien." Empatico (HumanidadMin 20) [ Mandos 2; Humanidad 4 ] "acto1_convocatoria" ]

          // --- Convocatoria de despliegue ---
          nodo "acto1_convocatoria" "Sargento Rubio"
              "Se publica la lista de voluntarios para Afganistán. «Quien quiera ir, que se apunte antes del viernes. Y que lo hable en casa.»"
              [ op "Apuntarme sin dudar." Disciplinado Siempre [ PonerBandera "se_apunto"; Disciplina 1 ] "acto1_lucia"
                op "Esperar unos días." Neutro Siempre [ Estres 4; PonerBandera "dudo" ] "acto1_lucia"
                op "Hablar primero con Lucía." Empatico Siempre [ Pareja 3; Humanidad 2 ] "acto1_lucia" ]

          // --- Conflicto central: el resultado está fijado ---
          nodo "acto1_lucia" "Lucía"
              "Han abierto plazas para Afganistán. Dime que no vas a pedirlo.\n\n(Algunas cosas no dependen solo de ti: tus palabras cambiarán cómo os despedís, no necesariamente lo que ocurra después.)"
              [ op "Es mi trabajo, Lucía." Disciplinado Siempre [ Pareja -10; Disciplina 2 ] "acto1_lucia_a"
                op "Déjame pensarlo." Neutro Siempre [ Estres 5 ] "acto1_lucia_b"
                op "Tienes razón en tener miedo." Empatico (HumanidadMin 30) [ Pareja 5; Humanidad 3 ] "acto1_lucia_c" ]

          nodo "acto1_lucia_a" "Lucía"
              "«Siempre es tu trabajo.» Asiente sin mirarte y recoge las llaves de la mesa. La puerta se cierra sin portazo, que es peor."
              [ op "Continuar." Neutro Siempre [ PonerBandera "despedida_fria"; PonerBandera "va_a_afganistan" ] "acto1_fin" ]

          nodo "acto1_lucia_b" "Lucía"
              "«Pensarlo.» Sonríe sin ganas. «Tú ya lo has pensado, Dani. Solo no sabes cómo decírmelo.»"
              [ op "Continuar." Neutro Siempre [ PonerBandera "despedida_confusa"; PonerBandera "va_a_afganistan" ] "acto1_fin" ]

          nodo "acto1_lucia_c" "Lucía"
              "Se le humedecen los ojos. «Gracias por no decirme que no pasa nada.» Te abraza un rato largo, sabiendo ambos lo que viene."
              [ op "Continuar." Neutro Siempre [ PonerBandera "despedida_sincera"; PonerBandera "va_a_afganistan" ] "acto1_fin" ]

          nodo "acto1_fin" "Narrador"
              "Fin del Acto I. Semanas después, el avión toca tierra en Afganistán."
              [ op "Continuar." Neutro Siempre [] "acto2_inicio" ] ]
