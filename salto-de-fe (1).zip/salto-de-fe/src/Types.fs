module Types

/// Tono de una respuesta: sirve para bloquear o desbloquear opciones según el estrés.
type Tono =
    | Neutro
    | Seco
    | Empatico
    | Disciplinado
    | Impulsivo

type Condicion =
    | Siempre
    | HumanidadMin of int
    | HumanidadEntre of int * int   // ambos extremos incluidos
    | EstresMax of int
    | DisciplinaMin of int
    | CompanerosMin of int
    | MandosMin of int
    | Bandera of string
    | No of Condicion
    | Alguna of Condicion list
    | Todas of Condicion list

type Efecto =
    | Estres of int
    | Humanidad of int
    | Resistencia of int
    | Fisico of int
    | Disciplina of int
    | Paracaidista of int
    | Mandos of int        // confianza
    | Companeros of int    // cohesión
    | Pareja of int        // vínculo
    | PonerBandera of string

type Atributo =
    | AFisico
    | ADisciplina
    | AParacaidista

/// Prueba determinista (sin azar): puntuación = atributo + bonus de resistencia - penalización de estrés.
type Prueba =
    { Atributo: Atributo
      Dificultad: int
      CosteResistencia: int
      SiExito: Efecto list
      SiguienteExito: string
      SiFallo: Efecto list
      SiguienteFallo: string }

type Opcion =
    { Texto: string
      Tono: Tono
      Condicion: Condicion
      Efectos: Efecto list
      Siguiente: string
      Prueba: Prueba option }

/// Evento con tiempo: si se agotan los segundos se ejecuta la opción por defecto (la reacción instintiva).
type Limite =
    { Segundos: int
      Defecto: Opcion }

type Estado =
    { // Atributos base (0-100)
      Fisico: int
      Disciplina: int
      Paracaidista: int
      // Variables derivadas
      Resistencia: int
      Estres: int
      Humanidad: int
      // Relaciones
      Mandos: int
      Companeros: int
      Pareja: int
      // Progreso
      Banderas: Set<string>
      NodoActual: string
      GuitarraUsada: bool }

type Nodo =
    { Id: string
      Personaje: string
      Texto: string
      /// Si existe, el texto se construye a partir del estado (epílogos, reacciones que dependen de las relaciones).
      Dinamico: (Estado -> string) option
      Opciones: Opcion list
      Limite: Limite option }
