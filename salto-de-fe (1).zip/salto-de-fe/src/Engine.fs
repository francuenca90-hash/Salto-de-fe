module Engine

open Types
open Rules

let nodoActual (e: Estado) : Nodo = Map.find e.NodoActual Content.nodos

/// Texto que se muestra: fijo o calculado según el estado.
let textoNodo (e: Estado) (n: Nodo) : string =
    match n.Dinamico with
    | Some f -> f e
    | None -> n.Texto

let opcionesDisponibles (e: Estado) (n: Nodo) : Opcion list =
    n.Opciones |> List.filter (opcionVisible e)

/// Texto del botón: las opciones con prueba muestran el atributo que se pone a prueba.
let etiqueta (o: Opcion) =
    match o.Prueba with
    | Some p -> sprintf "[%s] %s" (nombreAtributo p.Atributo) o.Texto
    | None -> o.Texto

/// Aplica la opción: resuelve la prueba si la hay, aplica efectos y avanza al siguiente nodo.
let elegir (e: Estado) (o: Opcion) : Estado =
    let resultado =
        match o.Prueba with
        | None -> aplicarEfectos e o.Efectos, o.Siguiente
        | Some p ->
            let ok = superaPrueba e p
            let e1 = aplicarEfecto e (Resistencia -p.CosteResistencia)
            let extra = if ok then p.SiExito else p.SiFallo
            aplicarEfectos e1 (o.Efectos @ extra), (if ok then p.SiguienteExito else p.SiguienteFallo)
    let e2, destino = resultado
    { e2 with NodoActual = destino; GuitarraUsada = false }

/// La guitarra reduce el estrés una vez por jornada/evento.
let tocarGuitarra (e: Estado) : Estado =
    if e.GuitarraUsada then
        e
    else
        { aplicarEfectos e [ Estres -10; Humanidad 1 ] with GuitarraUsada = true }

/// Descripción del nivel de estrés para la interfaz.
let nivelEstres (e: Estado) =
    if e.Estres < 40 then "sereno"
    elif e.Estres < 70 then "tenso"
    else "al límite"
