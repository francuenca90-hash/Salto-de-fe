module App

open Browser.Dom
open Types

let mutable estado : Estado =
    match Save.cargar () with
    | Some e when Map.containsKey e.NodoActual Content.nodos -> e
    | _ -> Rules.estadoInicial

let el (id: string) = document.getElementById id

// Aviso en consola si el guion tiene saltos a nodos inexistentes.
for problema in Content.validar () do
    console.warn problema

/// Cada render incrementa el ticket: así se invalida cualquier cuenta atrás anterior sin guardar ids de temporizador.
let mutable ticket = 0

let pintarEstado () =
    (el "estado").textContent <-
        sprintf
            "Resistencia %d/%d · Estrés %d (%s) · Humanidad %d · Mandos %d · Compañeros %d · Pareja %d"
            estado.Resistencia
            (Rules.resistenciaMax estado)
            estado.Estres
            (Engine.nivelEstres estado)
            estado.Humanidad
            estado.Mandos
            estado.Companeros
            estado.Pareja

let rec render () =
    ticket <- ticket + 1
    let nodo = Engine.nodoActual estado
    (el "personaje").textContent <- nodo.Personaje
    (el "texto").textContent <- Engine.textoNodo estado nodo
    pintarEstado ()

    let cont = el "opciones"
    cont.innerHTML <- ""

    for op in Engine.opcionesDisponibles estado nodo do
        let b = document.createElement "button"
        b.textContent <- Engine.etiqueta op
        b.addEventListener ("click", fun _ ->
            estado <- Engine.elegir estado op
            Save.guardar estado
            render ())
        cont.appendChild b |> ignore

    let guitarra = el "guitarra" :?> Browser.Types.HTMLButtonElement
    guitarra.disabled <- estado.GuitarraUsada

    match nodo.Limite with
    | Some l -> contar ticket l.Segundos l
    | None -> (el "tiempo").textContent <- ""

/// Cuenta atrás de un evento con tiempo; al llegar a 0 se aplica la reacción por defecto.
/// Si la app pasa a segundo plano (pantalla bloqueada, otra app), la cuenta se congela.
and contar (t: int) (restante: int) (l: Limite) =
    if t = ticket then
        if document.hidden then
            window.setTimeout ((fun () -> contar t restante l), 500) |> ignore
        else
            (el "tiempo").textContent <- sprintf "⏱ %d s" restante
            if restante <= 0 then
                estado <- Engine.elegir estado l.Defecto
                Save.guardar estado
                render ()
            else
                window.setTimeout ((fun () -> contar t (restante - 1) l), 1000) |> ignore

(el "guitarra").addEventListener ("click", fun _ ->
    estado <- Engine.tocarGuitarra estado
    Save.guardar estado
    render ())

(el "reiniciar").addEventListener ("click", fun _ ->
    Save.borrar ()
    estado <- Rules.estadoInicial
    render ())

render ()
