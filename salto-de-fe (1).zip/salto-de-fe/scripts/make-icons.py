"""Regenera los iconos PNG (requiere Pillow): python3 scripts/make-icons.py"""
from PIL import Image, ImageDraw

BG, GOLD, DARK = (20, 23, 26), (201, 162, 74), (20, 23, 26)

def dibujar(tam, escala=1.0, redondeado=True):
    S = 1024
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if redondeado:
        d.rounded_rectangle([0, 0, S, S], radius=200, fill=BG)
    else:
        d.rectangle([0, 0, S, S], fill=BG)
    # Contenido en una capa aparte para poder reducirlo (zona segura de los iconos "maskable")
    capa = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    c = ImageDraw.Draw(capa)
    c.pieslice([192, 230, 832, 670], 180, 360, fill=GOLD)           # campana
    for x in (232, 372, 512, 652, 792):                              # cuerdas
        c.line([(x, 450), (512, 700)], fill=GOLD, width=7)
    for x in (332, 422, 602, 692):                                   # gajos
        c.line([(x, 450), (512, 230)], fill=DARK, width=7)
    c.ellipse([484, 672, 540, 728], fill=GOLD)                       # cabeza
    c.rounded_rectangle([490, 735, 534, 815], radius=18, fill=GOLD)  # cuerpo
    c.line([(500, 815), (484, 880)], fill=GOLD, width=14)            # piernas
    c.line([(524, 815), (540, 880)], fill=GOLD, width=14)
    if escala != 1.0:
        n = int(S * escala)
        capa = capa.resize((n, n), Image.LANCZOS)
        img.alpha_composite(capa, ((S - n) // 2, (S - n) // 2))
    else:
        img.alpha_composite(capa)
    return img.resize((tam, tam), Image.LANCZOS)

dibujar(512).save("public/icons/icon-512.png", optimize=True)
dibujar(192).save("public/icons/icon-192.png", optimize=True)
dibujar(512, escala=0.72, redondeado=False).save("public/icons/icon-maskable-512.png", optimize=True)
