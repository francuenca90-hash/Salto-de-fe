// Empaqueta la salida de Fable (build/) en una web lista para publicar o para Capacitor (dist/).
// Uso: npm run bundle   (tras `npm run fable`)
import { build } from 'esbuild';
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';

const PRESUPUESTO_JS_KB = 250; // aviso si el bundle supera esto (gama baja)

// Fable conserva la estructura de carpetas respecto al .fsproj (build/src/App.js); se acepta también build/App.js.
const entrada = ['build/src/App.js', 'build/App.js'].find(existsSync);
if (!entrada) {
  console.error('No se encuentra la salida de Fable (build/src/App.js). Ejecuta antes: npm run fable');
  process.exit(1);
}

rmSync('dist', { recursive: true, force: true });
mkdirSync('dist/icons', { recursive: true });

await build({
  entryPoints: [entrada],
  bundle: true,
  minify: true,
  format: 'iife',          // un solo archivo, sin módulos ES: más compatible con WebViews antiguos
  target: ['es2017'],      // Chrome 58+ / WebView Android 7+
  outfile: 'dist/app.js',
  legalComments: 'none',
  logLevel: 'warning',
});

cpSync('public/icons', 'dist/icons', { recursive: true });
cpSync('public/manifest.webmanifest', 'dist/manifest.webmanifest');
cpSync('public/boot.js', 'dist/boot.js');

// Identificador de versión = hash del contenido; invalida la caché del service worker en cada cambio.
const hash = createHash('sha256');
for (const f of ['dist/app.js', 'public/index.html', 'public/boot.js', 'public/manifest.webmanifest']) {
  hash.update(readFileSync(f));
}
const id = hash.digest('hex').slice(0, 10);

writeFileSync('dist/index.html', readFileSync('public/index.html', 'utf8').replaceAll('__BUILD__', id));

const archivos = [
  './', 'index.html', 'app.js', 'boot.js', 'manifest.webmanifest',
  ...readdirSync('public/icons').map((f) => 'icons/' + f),
];
writeFileSync(
  'dist/sw.js',
  readFileSync('public/sw.js', 'utf8').replaceAll('__BUILD__', id).replaceAll('__ARCHIVOS__', JSON.stringify(archivos)),
);

// Informe de tamaños
let total = 0;
const kb = (n) => (n / 1024).toFixed(1) + ' KB';
for (const f of ['index.html', 'app.js', 'boot.js', 'sw.js', 'manifest.webmanifest']) {
  const n = statSync('dist/' + f).size;
  total += n;
  console.log(`  dist/${f.padEnd(22)} ${kb(n)}`);
}
for (const f of readdirSync('dist/icons')) total += statSync('dist/icons/' + f).size;
console.log(`Versión ${id} · total ${kb(total)}`);
if (statSync('dist/app.js').size > PRESUPUESTO_JS_KB * 1024) {
  console.warn(`Aviso: app.js supera ${PRESUPUESTO_JS_KB} KB; revisa dependencias o contenido.`);
}
