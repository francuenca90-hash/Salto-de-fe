// Servidor estático mínimo para probar dist/ (sin dependencias).
// Uso: npm run serve  →  http://localhost:8000
// En un móvil Android por USB: `adb reverse tcp:8000 tcp:8000` y abre http://localhost:8000 en Chrome
// (localhost cuenta como origen seguro, así que el service worker y la instalación PWA funcionan).
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';

const RAIZ = resolve('dist');
const PUERTO = Number(process.env.PORT || 8000);
const TIPOS = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.json': 'application/json',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
};

createServer(async (req, res) => {
  try {
    const ruta = new URL(req.url, 'http://x').pathname;
    const rel = normalize(decodeURIComponent(ruta === '/' ? '/index.html' : ruta));
    const archivo = join(RAIZ, rel);
    if (!archivo.startsWith(RAIZ)) { res.writeHead(403).end(); return; }
    const datos = await readFile(archivo);
    res.writeHead(200, {
      'Content-Type': TIPOS[extname(archivo)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(datos);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('No encontrado');
  }
}).listen(PUERTO, () => console.log(`Sirviendo dist/ en http://localhost:${PUERTO}`));
